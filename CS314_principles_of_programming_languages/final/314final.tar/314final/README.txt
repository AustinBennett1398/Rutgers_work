Group Members: Austin Bennett, Brett Conetta, Stephen Prospero

Required:
	Windows or Linux
	At least python 3.7.1
Preferred:
	Windows - Some graphical improvements exist on Windows that aren't possible on the Linux system.
	Python 3.7.1 is fine but the most up to date python is preferred.
	
To begin running:
	Simply run startup.py with python 3.7.1+.
	
	